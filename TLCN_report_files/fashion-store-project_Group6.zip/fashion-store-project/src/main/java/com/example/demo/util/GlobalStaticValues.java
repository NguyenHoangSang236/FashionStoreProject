package com.example.demo.util;

import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.example.demo.entity.Cart;
import com.example.demo.entity.Customer;
import com.example.demo.entity.Product;
import com.example.demo.entity.Staff;

import ch.qos.logback.core.status.Status;

public class GlobalStaticValues {
	public static int[] customerFullCartIdList = {};
	
	public static int[] customerSelectedCartIdList = {};
	
	public static int[] customerFullCartQuantityList = {};
	
	public static int[] customerFullSelectStatusList = {};
	
	public static int[] customerFullCartAvailableQuantityList = {};
	
	public static String[] customerFullCartSizeList = {};
	
	public static double customerInvoiceTotalPrice;
	
	public static Customer currentCustomer = new Customer();
	
	public static Staff currentStaff = new Staff();
	
	public static Product addToCartProduct = new Product();
	
	public static String message = "";
	
	public static String filterQuery = "";
	
	public static String currentPage = "/home";
	
	public static byte[] defaultUserImageByte = ValueRender.convertStringToByteArray("iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAh1BMVEX///8AAAD29vb8/Pz4+Pj09PQEBATv7+/t7e3m5uaxsbHGxsaSkpKEhITR0dE8PDw1NTVoaGimpqaCgoK5ublTU1MfHx/Y2NhGRkYvLy+KiookJCSRkZFVVVVwcHDc3NxgYGAWFhadnZ1AQEB7e3vKysoPDw9jY2O+vr5JSUmqqqobGxsqKirGfPeDAAANBElEQVR4nO1dB5uiPBAGgiIW7A0Vy6q3u+f//31fZgKsFTNJwD2/vPfcFpeQTKZkJmXiOBYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhbvhFoYjQbLYdLfbFabTT8ZLgejKKy9ullGwNbNeDxx72Myjptr9uomaiBoxbMHtJ1jFreCVzdVBVG7J0Fdhl47enWDaYj2R2x4/YKM+vxjvFqtxh/zq8/x63H/bxDJtWodXzGom+yaUehfPOeHUXOXdK+ejNf4ht+N0eycd73O6Ie0n7bnP/nhqJNLM5SajSpuLwW82UH7TO7mnZYnVdBrdeZnMt0Ofi0jG50zydyFpLLh4Exih42SWqgB4N8Q2IB8OBHJEwh3p/wNw9/HR3+Zi1lf3SZG/VzIl/7zx6tEM+/9pd7oHSxzjWwaaps+mLP+SJu1HeiLFhtsUxI/1r9FUuNMPr8dfe2B8t+ZrMYGWqcL5kSL1AK2zXU4S0cddxG9no1ZW5KGwbYwp5Fk/WbspWpo9IQ4zc37lNFc2K7uSwfHVqqBpXS0EFX+/lYZb5dpQC6h83VJVaznuaS+QBt5lX9E/Z3yamepH/jnBSQyJ+hxPSldhkAPeC29oGoSmROKGLer4oFSEAqP/BhWTeJU2Jh+BVX1hb2ZVlBVDj7MC/3YVVLdTlRW6eB/EHU2K6mToV/PcaigsrTGSMhNZTVCj9ar5OJUdOm0MqlhP1VWglBwsKxh/j7WgotlW24Hx0ExTFRLIJIIg0YF4yLrVW+7EWJ86pVf0Z/UclePKHPgykUb1aGaYeISYtColx0wtioc6G8hhv5SHeGGmC580cwCc8RkY3khMXNwiaGrVJQjiEa7ZbzcjaIg/4yILshpr7weFkqo1oWHThrOiqC5o+YQNcpVxamaGuCKzeWKIU5PKK3AtEr1bXDasEMtxRz/ekExQ+zTScSof0EtJYdY6AANnILRA/oAIzob0RaUMlW8RhUgOmvMYf2Mml78uQam+evPOF8V7TMqiWs0BmU4jbg20aa2pzFPZ/zjyzalS+F1d040XEzM8H3QSsm8t4kTv9RS65RVd2b885l78vrLHHrGuFvFsDFUdzQUMc9X41bd+O+NL+QiOSQSDqrpMRGX9RJSEcb87ZPhSwywW5/RmotrGktSkacIsNtoi5/M+UICRg/liaGdrbtfRIlTaU0xmDOEVRKqK7HDdeHPwmc+cfmF6sq3odTQpCYGKpIfYqFBYTuYM8CniKrIjDNxCLI0IBZaQUcnxUM6A6Xij62I7x6A/A+JhQqALNwSC6HFOz7fUcG2Klb6aJaJbSFuNKyeK6HApxoTXXPLlsxR1kK5ULKrrImmbM1IxZAi32VYCExU4AeaU1Pb/MD1cKmbshcE1QVNpAZENWjUF7HQA6BvSV1GQyGVjSU7CmIq5mzMhBixiq3DoFB2puKQhookRObiRHjTiVoIu0Vue6njeEqNPaGtMQDsqx3Vam14oYn003/50xtaBUzMnpqYfN+rKAnGyxvppzcqMS2q+p5a6g6OOK5RB54JqfY9ieMCDMfRI7HUHaRCSq0eBgB5vxG2F2/Jo7chMW0rCWklFIZmPDeYFSNOzwBOZCklm2ucsNFfUAwoI/cZ4NTFWPrpMX96Rq+kYyLAwN2HCutZfdJgpeI1OeqNu0AMoabCtnlUX9mp0IaiQvlAoa5bM1MU9RbFEUMXT4UXPTXpPgdTVEPh+svOPiYqwQugoxC4XmGq4hMj8GylnHj7riorkPl6S21NpdEQ8C0/84EzEt8qleCIqHfypCPPiSvgMCPnU6nPKvmqSvSDsfRkyw32MM0g4+7t4EFFD7pLGnbvYUKwF1cIJVddZJ+7i0TBZb9ATcntTjGElneLV0D5X7t1kgt7iZ2qFc4QKptSDr8O3EmKAy82XMx727rqUbyRsiVMcdCKT1q4zT5+PK+PRzaOk+NRbtbxDiLKdNA9aHUR45a4/iTE2G+P88nfjvLMrpaQAQbKg4UDK6TOygVBHT9SlGDsnhZHd8N8VQp9+VH3PtqUCMH3blay2UzsU/i8kVRY9f3kA2bv+HdcqylT6OgGwXh4WfJZxht6/ZHjp6fzx7fKHI1xK8b2K2A12WnHW+gYYkBCCfBvKcxeAeh9n3stje+uKzKe7B12w3sC5uoDNqIvO8vHPN9HCvkP/Fffx2/8N4+JI6/bLSQx+T5Mp9PWdwc4+/f09++Ru6MeMND3+Au8vJA8zR9qsXOODTpFz6vjcubVgEK/BrRhaz1oN//HQm5vFtv65HRM2elu3friCLPA45B3hs8LeECex0vDDg7+gy9n3hi6lRtNCiXWLqHXOWoeg5Yy5Ab/4sBvwJjWzD1ymzlZ8LGPv3HhLhbbY92dtbiAwrNYDEtx5omfapJcXGlSuHKlVmcZNi1AsvgP/EsAn2DjUfbYIUHWcRJdZChozwGk2Ul7A/rCT6kFOZAdoiRb+BCSPETxAksj9M8LatBU5Aanno8FIL+f+1mW22Pb3X8GDlLDUu6l35HWGv8v20JdHkrqITSLq6CXUchVEqQs+41TAnzk6hYeWq1DFIJV5ZZJaNwVhaCNaHFk9knp66GkLUVDgyKJJsJPmYHqCSYWKfQDMEQ8mBAyKJiVUSao5e/BZ7HDgkAmZtC1paA9MnPRvNtRtITBB1UCmtHkeEAh/w0p9AIcVDzofU/8dEkhKGYNOob5QS2Q4KLueCjt06SMYWIkY0BHrSaGOQ/tI9gfMCtItGg5/AmL4H9QS94TDD7h/eOwIJBRRl2fhuCXssvvLFUjVqRP7LygKPXzTW6/oq5fqhVbXKJxaMbJqjs/zburJG4eUh9Oc0OMdmyhHUILBKPkNu3eImnq79rSjg/1YnyB2vfjxHuzb83cidoxvmYXcRGc9h+SJ5BEOqKqLWRac22OiAHPEu/NV/1kn/RXP+eD4G93YkdpaM+1acyXcr5AUJFh3D6cd3Xj0D774ypU5aP2fKnOnDduGhL824vUdNnUafrda+1zPqouAurPeSuuW/CxbDpJW98tWjlpdtNemEwlB8ALGFi3UF57GmTWEgxdwXypc8gsrcqoZmDtSWn9kOXZOhYyC7utRZpFhHwEysT6odoasNcVoid76CPNQtclT7kZWANWWMdnTkPkNzvJd+4U9xm6C2q+MAPr+Cp7MdKkC38ojWXimP+R5scZ2YvxSd6yUlugiJKyV6VZterugjR6G9lPQ90TlZ73Jh+ey5LQkM5pG9kTRd7X1seDTCPq6MbwlBcvSpmSMLKvjbY3Md24qzhECS7Kb0c2tDeRtr90StfBDLkuSptgU9ugSXuET9BE9bmvPnTQSa4uY3uESfu8cYf+QsHBFGAMR1JJ+29snzdhr74416ycdZxlb5DpT1D5uqFEOeifSNUJiwiaqt92cSFCpouMnbeQPzMTAYF68SjDmFuyNo248hLS554wDtJ1MXBjqsyJLYPnnmTPrmGn6gXcgLFcRGTy7Jrc+cM0AZC+5kdCZJ5posnzh5JnSLFTPwxku/6QERmzZ0jlzgEPRKfqU4gi87w2Ix5bBqndsDMD8TYC2fMsrjV8llvmPL4xD0PKi0IWGjyPL5NTAQMDM/k+D0/DE+M5FWTyYiSmhDRtf+EAbD4vxtNsIsLebgzVtnnij5nPbeI8z0/TAE01lW0QfeqCI0Vl5Kd5mmOoZSgaRUTF7l8pOYae5olC42YqoWGjcPxlc2GJjKcWLM711TEWygDgZQ8m+MrK9eU8y9cGxsFcfthegdkqL19bcc69mUFTKvrrkVfTK/F6lqK8ib1iU0tE8lgiysybWJj78mTUixo+nDgpN/dlQf5SNjFO4eSeTSs5fykTOnB3XR/CX3PX3o0euW1l56AtyCPs72fFecsoYM5gtr9d0is/j7DzOBf0zR48PTx4XQW5oF+fz7uCC6DePif7++fV/x/cjfD291sA3v6Okv/BPTNvf1dQxsW7Q38ZeMV9T29/Zxdw8e3vXXv7u/PQL87uPyyxlhfef5jv8HHf9g5LRHYPqen5Z8TL7yFFNLpuiXfJuq+/S9Z5//uAnf/Bnc7Ou9/L7UCb3v5udUescdeFWYWFS+Wde06QnkxwdU+KGIe/zBrm9sGuKu2gdaJ+Jp/u0szRVWPgzQuGee+fdirearg75W8Yqtx2VT4aqY+FHvmARmS46/4U7hheojcF4GNq5ZEP805L7piP1xJ3sqVHMZVuK6sQo9lPW1231xmFuULdabYfjjr57VZQamZu8aMksPyyqjOJTXbNKLy0HH4YNXdJ9+rJWHkHddWI9scfac1Rn3+MV6vV+GN+9Tl+Pe5fMZGugajdc+XRa/9j5AkErfjxUfwfzOLWL7WdUmDTZjy+TaggMBnHzem/oXfPUAuj0WA5TPqbzWqz6SfD5WAUhZr5FCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCx+Gf4DwJCMmhHfXFgAAAAASUVORK5CYII=");
	
	public static List<Cart> customerFullCartList = new ArrayList<Cart>();
	
	public static boolean[] customerCheckedCartList(int[] selectStatusArr) {
		boolean[] tmpArr = new boolean[selectStatusArr.length];
		
		for(int i = 0; i < tmpArr.length; i++) {
			if(selectStatusArr[i] == 0) {
				tmpArr[i] = false;
			} else {
				tmpArr[i] = true;
			}
		}
		
		return tmpArr;
	}
	
	public static EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("persistence");
	public static EntityManager entityManager = entityManagerFactory.createEntityManager();
}
